README       22 November 2002, updated 21 December 2005



TRIGRS

 A Fortran program for analyzing time-dependent rainfall infiltration and slope stability in a digital landscape





TRIGRS, version 1.0.03



  This distribution includes source code and executable files for the program TRIGRS and two companion utility programs, TopoIndex and UnitConvert.  Executable files are available for Windows 98/NT/2000/XP/2003 and for Mac OSX version 10.2 or higher.  The code can be compiled for Unix or other platforms that support Fortran 90/95 and Fortran 77.  



CONTENTS

DISTRIBUTION FILE

DOCUMENTATION

EXTRACTING AND INSTALLING THE FILES

SOFTWARE DESCRIPTION

  Overview

  UnitConvert

  TopoIndex

  TRIGRS

SUPPORT

DISCLAIMER

VERSION HISTORY



*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-



DISTRIBUTION FILE

  The following distribution files are available:

Documentation: OFR-02-0424.pdf

For Windows:  OFR-02-0424.exe

For Mac OS: OFR-02-0424.smi



  These files are available from the USGS at

http://pubs.usgs.gov/of/2002/ofr-02-424/



  The latest version of the programs is avaialable at 

http://landslides.usgs.gov/research/technology.php 
or by contacting Rex Baum <baum@usgs.gov>



DOCUMENTATION



  The documentation for TRIGRS is contained in the text of U.S. Geological Survey Open-File Report 02-0424, which is saved in PDF format as "OFR-02-0424.pdf". The documentation can be viewed using Adobe Acrobat Reader.  This documentation includes a user guide and tutorial.  





EXTRACTING AND INSTALLING THE FILES



  The computer programs are saved as self-extracting archives for PC and Macintosh computers and must be downloaded separately.  These archives contain the compiled applications, make files, source code, and sample data.  



  To use the PC version, download the file "OFR-02-0424.exe" to the hard disk and double click on its icon to extract the files.  Use the dialog to select the desired target folder and click "OK" to extract the TRIGRS folder and its contents into the target location. The documentation can be downloaded and copied to the folder "Documentation" within the "TRIGRS" folder.  The PC version of TRIGRS and its companion programs require Windows 98 or later and compatible hardware.  Memory and disk requirements vary as explained in the documentation.



  To use the Mac version, download the file "OFR-02-0424.smi" to the hard disk and double click on the icon to mount an image file on the desktop.  Double-click the icon of the image file, "TRIGRS_update" to see the contents.  The image file is locked, so copy the folder  "TRIGRS_1.0.3" to any convenient folder on the hard drive, preferably within your "home" folder. The documentation can be downloaded and copied to the folder "Documentation" within the TRIGRS_1.0.03 folder. The Mac version of TRIGRS and its companion programs require Mac OS X, version 10.2 or later and now run on the command line.  See ReadMeMac.txt for more information.  Memory and disk requirements vary as explained in the documentation.



SOFTWARE DESCRIPTION



Overview

  TRIGRS is a tool to be used by investigators who have some knowledge and experience concerning landslide behavior. Selecting input parameters and interpreting results requires geologic and engineering judgment as well as common sense.  The user should understand the theory and limitations behind TRIGRS, which are outlined in the documentation.  The user must also be aware of the limitations of the digital elevation model, physical properties and hydrologic data that TRIGRS uses as input for analyses.



 TRIGRS and its companion utility programs, TopoIndex and UnitConvert, run in simple input-output windows and have limited user interaction.  Each program uses an initialization file that contains basic data needed to run the program as well as the names of other input files.  At the beginning of a project, the user would prepare a digital elevation model, slope grid, flow-direction grid, and physical properties grid files using Geographic Information System (GIS) software.  Next, if needed, the user would run UnitConvert to put the physical properties grid files into a consistent system of units.  The user should then run TopoIndex using the digital elevation model and direction grid file as input to define the flow distribution pattern and compute weighting factors for distributing surface runoff.  Routing and distribution of surface runoff is optional; however, TopoIndex will compute array sizes from the digital elevation model to be used by TRIGRS, and so the user should run TopoIndex once at the beginning of a project to determine array sizes.  After preparing the topographic and physical properties data, converting the data to consistent units, computing array sizes and (if desired) preparing the flow distribution data, the project is ready for analysis using TRIGRS.  The user may run TRIGRS as many times as necessary to establish a time-series response of shallow pore water and stability of shallow slope deposits to rainfall infiltration.  Each run of TRIGRS computes the pore pressure and factor of safety over the grid for a particular, user-specified, instant in time.    



  The three programs have similar user interfaces.  When the user double-clicks the program icon, the program immediately launches and looks for the initialization file, which should be in the same folder as the program.  If a program does not find its default initialization file (trigrs.ini, topoindex.ini, or unitconvert.ini), it will prompt the user to enter the name of the file.  Once the program finds an initialization file, it will open and read it, open any needed input files that were listed in the initialization file, complete the specified computations, save the computations to files and quit.  In the event of input or output errors, error messages will appear on screen to help the user trace the source of the problem.  Please consult the tutorial (in the main report describing TRIGRS) for details of preparing the data and initialization files.



UnitConvert



  Use UnitConvert at the beginning of a project if you need to convert the data in a grid from one system of units to another.  UnitConvert reads the contents of an input grid file, multiplies each grid value by a conversion factor, and saves the result to the output grid file.  Input and output grids have the same resolution.  UnitConvert uses an initialization file and one input file of data in ASCII grid format; it produces one output file of data, also in ASCII grid format.  The initialization file contains three lines input data that contain the name of the input file, the name of the output file and the conversion factor.  A descriptive header appears above each line of input data to aid the user.





TopoIndex



  Use TopoIndex at the beginning of a project to compute array sizes for TRIGRS and to prepare runoff routing data if you want TRIGRS to route excess water to downslope cells.  It should be necessary to run TopoIndex only once for a project after you have chosen a routing method and created a hydrologically consistent DEM and flow-direction grid.  TopoIndex uses an initialization file and two input files to determine the correct order for runoff routing calculations and to compute the weighting factors that determine how excess water is distributed to neighboring downslope grid cells.  Only one of the input files (a digital elevation model of the study area) is needed to determine array sizes for running TRIGRS if the user chooses to neglect runoff routing.





TRIGRS



  Use TRIGRS to compute the shallow time-dependent pore-pressure and slope-stability response of an area subject to rainfall.  TRIGRS is based on superposition of one-dimensional infiltration on a general steady flow field to determine pore-pressure response and an infinite-slope model to determine stability of shallow soils during storms.  Each simulation with TRIGRS analyzes a single, user-specified point in time during a storm sequence.  Thus, the user runs a series of simulations for different specified times using TRIGRS to study the time history of slope instability during a rainfall sequence.  If desired, TRIGRS can use a simple (built-in) runoff-routing model to divert excess water to downslope areas where it has the opportunity to infiltrate.  TRIGRS uses an initialization file and one or more input files, depending on the variability of physical properties and rainfall in the study area.



SUPPORT



  There is no formal ongoing support for this freely distributed public domain software.  However, we are interested in feedback. If you find errors or have suggestions, please contact:



Rex Baum baum@usgs.gov 



DISCLAIMER



  This open-file report was prepared by an agency of the United States Government. Neither the United States Government nor any agency thereof nor any of their employees makes any warranty, expressed or implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, product, or process disclosed in this report or represents that its use would not infringe privately owned rights. Reference therein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise does not constitute or imply its endorsement, recommendation, or favoring by the United States Government or any agency thereof. 



  Although all data and software in this open-file report have been used by the USGS, no warranty, expressed or implied, is made by the USGS as to the accuracy of the data and related materials and (or) the functioning of the software. The act of distribution shall not constitute any such warranty, and no responsibility is assumed by the USGS in the use of these data, software, or related materials. 





VERSION HISTORY



  TRIGRS 1.0.03, December 21, 2005, Corrected error in Iverson's (2000) coordinate transformation (Thanks to Silvia Simoni, Prof. Riccardo Rigon and his colleagues at Universita di Trento, Trento, Italy for pointing out the error)
 

  TRIGRS 1.0.02 March 12, 2004, Corrected error in subroutine Savage() by replacing depth() with zmax().



  TRIGRS 1.0   August 27, 2003, Corrected initialization of variable rf in subroutine Savage(). 



  TRIGRS 1.0   22 November 2002, Original

  TopoIndex 1.0.01, December 21, 2005, Improved handling of "nodata" values to allow different nodata values for integer and floating point grids (Thanks to Manfred Th�ring, Institute of Earth Sciences -SUPSI, Ticino, Switzerland for pointing out this problem).  Also converted the subroutine nxtcel() to Fortran 90/95 to improve its loop structure.

