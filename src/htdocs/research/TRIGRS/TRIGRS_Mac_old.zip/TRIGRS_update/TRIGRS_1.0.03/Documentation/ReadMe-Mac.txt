TRIGRS version 1.0.03 for Mac OSX

This version of TRIGRS, TopoIndex, and UnitConvert has been compiled to run inside the Terminal application.  We made this change because TRIGRS runs faster and our compiler provides better error reporting for Terminal applications than for stand-alone applications.  As a result of this change, the program initialization files now use POSIX path names and the all input files must have UNIX line endings.  This change should be an advantage to users of GRASS GIS on the Mac.  


The following is a quick start guide for users unfamiliar with the Terminal.  Terminal is a command-line interface for Mac OS X and provides access to the underlying UNIX functions in the Mac OS.   

1.  Copy the entire contents of the TRIGRS_1.03 archive to your hard drive, preferably to a directory in your home folder.

2. Launch Terminal by double clicking its icon; Terminal is found in the folder /Applications/Utilities.

3. Change to the TRIGRS folder.  To do this, type the command "cd", press the space bar, and then type the path name of the folder that contains "trigrs.ini" and press return.  If you don't know the path name, then open the folder in the finder, click on the small folder icon in the top of the window, and drag onto the terminal window.  Once you release the mouse button, the path name should appear on the command line, and you can press return.

4. Drag the icon for TRIGRS.command onto the terminal window.  When you release the mouse button, the full path name of the file should appear on the command line.  Press return and TRIGRS should begin running.  The command-line prompt (a line of text ending with $) should appear when the program is finished.  In case of problems, the program can be aborted by typing simultaneously "control" + "c". The programs "TopoIndex" and "UnitConvert" work in a similar manner.

A sample terminal session appears below:

Last login: Thu Oct  6 15:01:03 on ttyp2
Welcome to Darwin!
Rex-Baums-G5:~ baum$ cd /Users/baum/FortranApps/TRIGRS_suite/TRIGRS_1.03/ 
Rex-Baums-G5:~/FortranApps/TRIGRS_suite/TRIGRS_1.03 baum$ /Users/baum/FortranApps/TRIGRS_suite/TRIGRS_1.03/UnitConvert.command 
    UnitConvert: A simple utility for
   converting ASCII grid data from one
       system of units to another
              By Rex L. Baum
         U.S. Geological Survey
 -----------------------------------------
 Portions of this program include material
            copyrighted (C) by
       Absoft Corporation 1988-2002.
 
Rex-Baums-G5:~/FortranApps/TRIGRS_suite/TRIGRS_1.03 baum$ 

